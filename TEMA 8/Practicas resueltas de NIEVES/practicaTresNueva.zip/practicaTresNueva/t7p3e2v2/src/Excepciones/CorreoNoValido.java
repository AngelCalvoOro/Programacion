package Excepciones;

public class CorreoNoValido extends Exception{
    
}
