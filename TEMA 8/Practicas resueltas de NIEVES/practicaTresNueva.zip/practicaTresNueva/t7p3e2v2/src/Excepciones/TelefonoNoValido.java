package Excepciones;

public class TelefonoNoValido extends Exception{
    
}
