package UML;

public class SocioIndividual extends Socio{
    
    public SocioIndividual(String n, String a, String t, String c) {
        super(n,a,t,c);
    }
}
