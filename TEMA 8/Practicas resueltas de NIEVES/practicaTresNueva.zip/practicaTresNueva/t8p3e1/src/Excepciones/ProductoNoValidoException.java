package Excepciones;

public class ProductoNoValidoException extends Exception{

}
